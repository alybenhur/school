<template>
  <Header_Pagina/>
  <Carrusel_Compo></Carrusel_Compo>
  <InstitucionalApp></InstitucionalApp>
  <AppFooter></AppFooter>
 
</template>


<style>
body{
  background-color: blue;
}
</style>


