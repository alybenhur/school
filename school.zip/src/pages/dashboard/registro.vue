<template>
    <h1>Aqui va el registro</h1>
</template>