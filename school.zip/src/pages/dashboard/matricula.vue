<template>
    <h1>Aqui van las matriculas</h1>
    </template>