<template>
     <v-container>
    <h2>Detalles del producto</h2>
    <router-view /> <!-- 👈 Aquí se cargan las rutas hijas -->
  </v-container>
</template>